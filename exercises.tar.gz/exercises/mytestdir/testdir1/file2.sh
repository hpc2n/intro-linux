touch file1.txt
